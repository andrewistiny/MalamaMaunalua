module.exports = {
    MongoURI: 'mongodb+srv://malamawarriors:rlfa123@malamamaunalua-xxwnm.mongodb.net/test?retryWrites=true'
}
 